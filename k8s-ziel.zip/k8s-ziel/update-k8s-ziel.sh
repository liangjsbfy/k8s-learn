#!/bin/bash

#说明：本脚用于定期更新k8s istio证书，每个新增的证书需要更改模版文件和本脚本

#新的配置文件
if [ -f k8s-ziel-domain-cert.yaml ];then
	rm k8s-ziel-domain-cert.yaml
fi

cp k8s-ziel-domain-cert.yaml.template k8s-ziel-domain-cert.yaml

######################## 更新域名配置写里 ########################

#更新zieldev.com
zieldev_com_tls_crt=$(cat /root/.acme.sh/zieldev.com/fullchain.cer |base64 -w0)
zieldev_com_tls_key=$(cat /root/.acme.sh/zieldev.com/zieldev.com.key |base64 -w0)

sed -i "s/{zieldev_com_tls_crt}/${zieldev_com_tls_crt}/g" k8s-ziel-domain-cert.yaml
sed -i "s/{zieldev_com_tls_key}/${zieldev_com_tls_key}/g" k8s-ziel-domain-cert.yaml

#更新zielhome.com
zielhome_com_tls_crt=$(cat /root/.acme.sh/zielhome.com/fullchain.cer |base64 -w0)
zielhome_com_tls_key=$(cat /root/.acme.sh/zielhome.com/zielhome.com.key |base64 -w0)

sed -i "s/{zielhome_com_tls_crt}/${zielhome_com_tls_crt}/g" k8s-ziel-domain-cert.yaml
sed -i "s/{zielhome_com_tls_key}/${zielhome_com_tls_key}/g" k8s-ziel-domain-cert.yaml

#更新ziel.cn
ziel_cn_tls_crt=$(cat /root/.acme.sh/\*.ziel.cn/fullchain.cer |base64 -w0)
ziel_cn_tls_key=$(cat /root/.acme.sh/\*.ziel.cn/\*.ziel.cn.key |base64 -w0)

sed -i "s/{ziel_cn_tls_crt}/${ziel_cn_tls_crt}/g" k8s-ziel-domain-cert.yaml
sed -i "s/{ziel_cn_tls_key}/${ziel_cn_tls_key}/g" k8s-ziel-domain-cert.yaml

#更新songmics.com
songmics_com_tls_crt=$(cat /root/.acme.sh/songmics.com/fullchain.cer |base64 -w0)
songmics_com_tls_key=$(cat /root/.acme.sh/songmics.com/songmics.com.key |base64 -w0)

sed -i "s/{songmics_com_tls_crt}/${songmics_com_tls_crt}/g" k8s-ziel-domain-cert.yaml
sed -i "s/{songmics_com_tls_key}/${songmics_com_tls_key}/g" k8s-ziel-domain-cert.yaml


#更新songmics.de
songmics_de_tls_crt=$(cat /root/.acme.sh/songmics.de/fullchain.cer |base64 -w0)
songmics_de_tls_key=$(cat /root/.acme.sh/songmics.de/songmics.de.key |base64 -w0)

sed -i "s/{songmics_de_tls_crt}/${songmics_de_tls_crt}/g" k8s-ziel-domain-cert.yaml
sed -i "s/{songmics_de_tls_key}/${songmics_de_tls_key}/g" k8s-ziel-domain-cert.yaml

#更新songmics.fr
songmics_fr_tls_crt=$(cat /root/.acme.sh/songmics.fr/fullchain.cer |base64 -w0)
songmics_fr_tls_key=$(cat /root/.acme.sh/songmics.fr/songmics.fr.key |base64 -w0)

sed -i "s/{songmics_fr_tls_crt}/${songmics_fr_tls_crt}/g" k8s-ziel-domain-cert.yaml
sed -i "s/{songmics_fr_tls_key}/${songmics_fr_tls_key}/g" k8s-ziel-domain-cert.yaml

#更新songmics.co.uk
songmics_co_uk_tls_crt=$(cat /root/.acme.sh/songmics.co.uk/fullchain.cer |base64 -w0)
songmics_co_uk_tls_key=$(cat /root/.acme.sh/songmics.co.uk/songmics.co.uk.key |base64 -w0)

sed -i "s/{songmics_co_uk_tls_crt}/${songmics_co_uk_tls_crt}/g" k8s-ziel-domain-cert.yaml
sed -i "s/{songmics_co_uk_tls_key}/${songmics_co_uk_tls_key}/g" k8s-ziel-domain-cert.yaml
############################### end ##############################
if [ $? -ne 0 ];then
    echo "脚本设置有问题"
    exit 1
fi

#更新到k8s中
kubectl --kubeconfig=k8s.config apply -f k8s-ziel-domain-cert.yaml

#平滑更新deployment 的pod
kubectl --kubeconfig=k8s.config patch deployment istio-ingressgateway -n istio-system   -p '{"spec":{"template":{"spec":{"containers":[{"name":"istio-proxy","env":[{"name":"RESTART_","value":"'$(date +%s)'"}]}]}}}}'
